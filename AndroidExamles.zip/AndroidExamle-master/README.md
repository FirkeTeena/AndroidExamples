# AndroidExamle
This is some very basic andriod example, for the beginers
