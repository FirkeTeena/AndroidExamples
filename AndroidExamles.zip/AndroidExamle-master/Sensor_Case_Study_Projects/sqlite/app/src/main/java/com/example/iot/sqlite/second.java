package com.example.iot.sqlite;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class second extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.secondactivity);
        }
}
